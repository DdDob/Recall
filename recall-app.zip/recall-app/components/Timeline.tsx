import { TimelineEntry } from "@/lib/mockData";

const tagStyles: Record<TimelineEntry["tag"], string> = {
  buy: "text-teal border-teal/40 bg-teal/10",
  miss: "text-signal border-signal/40 bg-signal/10",
  loss: "text-coral border-coral/40 bg-coral/10",
  reward: "text-signal border-signal/40 bg-signal/10",
  risk: "text-coral border-coral/40 bg-coral/10",
};

const tagLabels: Record<TimelineEntry["tag"], string> = {
  buy: "Buy",
  miss: "Missed",
  loss: "Loss",
  reward: "Reward",
  risk: "Risk",
};

export default function Timeline({ entries }: { entries: TimelineEntry[] }) {
  return (
    <div className="ledger-rail pl-12">
      {entries.map((entry) => (
        <div key={entry.id} className="relative pb-10 last:pb-0">
          <span className="ledger-sprocket" style={{ top: "0.35rem" }} />
          <div className="mb-1 flex items-baseline gap-3 font-mono text-xs text-ash">
            <span>{entry.year}</span>
            <span>·</span>
            <span>{entry.date}</span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <h3 className="font-display text-lg text-paper">{entry.title}</h3>
            <span
              className={`rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide ${tagStyles[entry.tag]}`}
            >
              {tagLabels[entry.tag]}
            </span>
          </div>
          <p className="mt-1 max-w-md text-sm text-ash">{entry.detail}</p>
        </div>
      ))}
    </div>
  );
}
