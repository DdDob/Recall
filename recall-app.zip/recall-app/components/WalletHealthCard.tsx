type Breakdown = {
  label: string;
  value: number;
  severity: "high" | "medium" | "low";
  isPercent?: boolean;
};

const severityColor: Record<Breakdown["severity"], string> = {
  high: "bg-coral",
  medium: "bg-signal",
  low: "bg-teal",
};

export default function WalletHealthCard({
  score,
  breakdown,
}: {
  score: number;
  breakdown: Breakdown[];
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-ink-light p-6">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-lg text-paper">Wallet Health</h3>
        <div className="flex items-baseline gap-1">
          <span className="font-mono text-3xl text-signal">{score}</span>
          <span className="font-mono text-sm text-ash">/100</span>
        </div>
      </div>
      <div className="mt-5 space-y-4">
        {breakdown.map((item) => (
          <div key={item.label}>
            <div className="mb-1 flex justify-between text-xs text-ash">
              <span>{item.label}</span>
              <span className="font-mono">
                {item.value}
                {item.isPercent ? "%" : ""}
              </span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-white/5">
              <div
                className={`h-1.5 rounded-full ${severityColor[item.severity]}`}
                style={{
                  width: `${item.isPercent ? item.value : Math.min(100, item.value * 20)}%`,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
