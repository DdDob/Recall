"use client";

import { useState } from "react";

export default function AskRecall({ samples }: { samples: string[] }) {
  const [query, setQuery] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);

  function handleAsk(q: string) {
    setQuery(q);
    // Wire this up to your AI backend (OpenAI API call over the user's
    // indexed transaction history). Placeholder response for the demo:
    setAnswer(
      `Based on your connected wallets, this would surface a grounded answer generated from your real transaction history — not a canned response.`
    );
  }

  return (
    <div className="rounded-2xl border border-white/10 bg-ink-light p-6">
      <h3 className="font-display text-lg text-paper">Ask Recall</h3>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleAsk(query);
        }}
        className="mt-4 flex gap-2"
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Where did I lose the most money?"
          className="flex-1 rounded-lg border border-white/10 bg-ink px-3 py-2 text-sm text-paper placeholder:text-ash/60 focus:border-signal/50 focus:outline-none"
        />
        <button
          type="submit"
          className="rounded-lg bg-signal px-4 py-2 text-sm font-medium text-ink hover:opacity-90"
        >
          Ask
        </button>
      </form>
      <div className="mt-3 flex flex-wrap gap-2">
        {samples.map((s) => (
          <button
            key={s}
            onClick={() => handleAsk(s)}
            className="rounded-full border border-white/10 px-3 py-1 text-xs text-ash hover:border-signal/40 hover:text-signal"
          >
            {s}
          </button>
        ))}
      </div>
      {answer && (
        <p className="mt-4 rounded-lg bg-ink px-4 py-3 text-sm text-paper/90">{answer}</p>
      )}
    </div>
  );
}
