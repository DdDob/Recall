import Link from "next/link";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/5 bg-ink/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="font-display text-xl tracking-tight text-paper">
          Recall
        </Link>
        <nav className="hidden gap-8 text-sm text-ash md:flex">
          <Link href="/#features" className="hover:text-paper transition-colors">
            Features
          </Link>
          <Link href="/#pricing" className="hover:text-paper transition-colors">
            Pricing
          </Link>
          <Link href="/dashboard" className="hover:text-paper transition-colors">
            Dashboard
          </Link>
        </nav>
        <Link
          href="/dashboard"
          className="rounded-full border border-signal/40 px-4 py-2 text-sm text-signal transition-colors hover:bg-signal hover:text-ink"
        >
          Connect Wallet
        </Link>
      </div>
    </header>
  );
}
