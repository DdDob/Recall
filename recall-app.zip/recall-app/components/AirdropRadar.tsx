type Airdrop = {
  protocol: string;
  wallet: string;
  estValue: string;
  status: string;
};

export default function AirdropRadar({ airdrops }: { airdrops: Airdrop[] }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-ink-light p-6">
      <h3 className="font-display text-lg text-paper">Airdrop Radar</h3>
      <div className="mt-4 divide-y divide-white/5">
        {airdrops.map((a) => (
          <div key={a.protocol} className="flex items-center justify-between py-3">
            <div>
              <p className="text-sm text-paper">{a.protocol}</p>
              <p className="font-mono text-xs text-ash">{a.wallet}</p>
            </div>
            <div className="text-right">
              <p className="font-mono text-sm text-signal">{a.estValue}</p>
              <p className="text-xs text-ash">{a.status}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
