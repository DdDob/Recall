"use client";

import { useState } from "react";
import { connectInjectedWallet, shortenAddress } from "@/lib/wallet";

export default function ConnectWalletButton({
  onConnected,
}: {
  onConnected?: (address: string) => void;
}) {
  const [address, setAddress] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleConnect() {
    setLoading(true);
    setError(null);
    try {
      const wallet = await connectInjectedWallet();
      setAddress(wallet.address);
      onConnected?.(wallet.address);
    } catch (err: any) {
      setError(err.message ?? "Failed to connect wallet.");
    } finally {
      setLoading(false);
    }
  }

  if (address) {
    return (
      <div className="flex items-center gap-2 rounded-full border border-teal/40 bg-teal/10 px-4 py-2 font-mono text-sm text-teal">
        <span className="h-2 w-2 rounded-full bg-teal" />
        {shortenAddress(address)}
      </div>
    );
  }

  return (
    <div className="flex flex-col items-start gap-2">
      <button
        onClick={handleConnect}
        disabled={loading}
        className="rounded-full bg-signal px-5 py-2.5 text-sm font-medium text-ink transition-opacity hover:opacity-90 disabled:opacity-60"
      >
        {loading ? "Connecting…" : "Connect Wallet"}
      </button>
      {error && <p className="max-w-xs text-xs text-coral">{error}</p>}
    </div>
  );
}
