export type TimelineEntry = {
  id: string;
  year: string;
  date: string;
  title: string;
  detail: string;
  tag: "buy" | "miss" | "loss" | "reward" | "risk";
};

export const mockTimeline: TimelineEntry[] = [
  {
    id: "t1",
    year: "2023",
    date: "Mar 14",
    title: "Bought 12.4 SOL",
    detail: "Entry at $21.80. Still held in Wallet A.",
    tag: "buy",
  },
  {
    id: "t2",
    year: "2024",
    date: "Jan 31",
    title: "Missed Jupiter airdrop",
    detail: "Wallet B qualified for ~1,400 JUP. Never claimed.",
    tag: "miss",
  },
  {
    id: "t3",
    year: "2024",
    date: "Jul 09",
    title: "Approved unlimited spend",
    detail: "Unlimited USDC approval to an unverified router contract.",
    tag: "risk",
  },
  {
    id: "t4",
    year: "2025",
    date: "Feb 22",
    title: "Lost $500 on memecoins",
    detail: "Four low-liquidity tokens, avg hold time 6 hours.",
    tag: "loss",
  },
  {
    id: "t5",
    year: "2026",
    date: "Jun 03",
    title: "3 claimable rewards found",
    detail: "Across two wallets: staking yield + two token claims.",
    tag: "reward",
  },
];

export const mockWalletHealth = {
  score: 68,
  breakdown: [
    { label: "Dangerous approvals", value: 2, severity: "high" as const },
    { label: "Wallet concentration", value: 71, severity: "medium" as const, isPercent: true },
    { label: "Scam token exposure", value: 5, severity: "low" as const },
    { label: "Dust attack flags", value: 1, severity: "low" as const },
  ],
};

export const mockAirdrops = [
  { protocol: "Jupiter", wallet: "Wallet B", estValue: "~$2,100", status: "Unclaimed" },
  { protocol: "LayerZero", wallet: "Wallet A", estValue: "~$340", status: "Eligible, unconfirmed" },
  { protocol: "Blast", wallet: "Wallet C", estValue: "~$85", status: "Unclaimed" },
];

export const mockDNA = {
  riskProfile: "Balanced",
  personality: "Airdrop Farmer",
  opportunityScore: 42,
};

export const mockAskRecallSamples = [
  "Where did I lose the most money?",
  "Which wallet made me the most profit?",
  "Which tokens did I sell too early?",
  "How much did I spend on memecoins?",
];
