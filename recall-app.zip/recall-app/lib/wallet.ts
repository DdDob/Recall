"use client";

import { BrowserProvider } from "ethers";

export type ConnectedWallet = {
  address: string;
  chainId: string;
};

declare global {
  interface Window {
    ethereum?: any;
  }
}

/**
 * Connects to whatever EIP-1193 injected wallet is available
 * (MetaMask, Rabby, Coinbase Wallet, etc). This is a real connection —
 * no mock data involved. Requires the user to have a wallet extension
 * installed in their browser.
 */
export async function connectInjectedWallet(): Promise<ConnectedWallet> {
  if (typeof window === "undefined" || !window.ethereum) {
    throw new Error(
      "No injected wallet found. Install MetaMask (or another EIP-1193 wallet) and try again."
    );
  }

  const provider = new BrowserProvider(window.ethereum);
  const accounts: string[] = await provider.send("eth_requestAccounts", []);

  if (!accounts || accounts.length === 0) {
    throw new Error("Wallet connection was rejected.");
  }

  const network = await provider.getNetwork();

  return {
    address: accounts[0],
    chainId: network.chainId.toString(),
  };
}

export function onAccountsChanged(callback: (accounts: string[]) => void) {
  if (typeof window === "undefined" || !window.ethereum) return () => {};
  window.ethereum.on?.("accountsChanged", callback);
  return () => window.ethereum?.removeListener?.("accountsChanged", callback);
}

export function shortenAddress(address: string) {
  return `${address.slice(0, 6)}…${address.slice(-4)}`;
}
