/**
 * Real Helius integration (server-side only — uses your secret API key).
 *
 * Requires HELIUS_API_KEY in .env.local. Get one free at https://www.helius.dev/
 *
 * Uses Helius's enhanced transactions API to pull real Solana wallet history.
 * Docs: https://docs.helius.dev/solana-apis/enhanced-transactions-api
 */

const HELIUS_BASE = "https://api.helius.xyz/v0";

export type HeliusTransaction = {
  signature: string;
  timestamp: number;
  type: string;
  description: string;
  fee: number;
};

export async function getSolanaTransactionsForAddress(
  address: string
): Promise<HeliusTransaction[]> {
  const apiKey = process.env.HELIUS_API_KEY;
  if (!apiKey) {
    throw new Error("HELIUS_API_KEY is not set. Add it to .env.local.");
  }

  const url = `${HELIUS_BASE}/addresses/${address}/transactions?api-key=${apiKey}`;

  const res = await fetch(url);

  if (!res.ok) {
    throw new Error(`Helius request failed: ${res.status} ${res.statusText}`);
  }

  const data = await res.json();

  return (data ?? []).map((t: any) => ({
    signature: t.signature,
    timestamp: t.timestamp,
    type: t.type,
    description: t.description,
    fee: t.fee,
  }));
}
