/**
 * Real Alchemy integration (server-side only — never call this from the client,
 * since it uses your secret API key).
 *
 * Requires ALCHEMY_API_KEY in .env.local. Get one free at https://www.alchemy.com/
 *
 * Uses Alchemy's Enhanced APIs (getAssetTransfers) to pull real wallet history.
 * Docs: https://docs.alchemy.com/reference/alchemy-getassettransfers
 */

const ALCHEMY_BASE = "https://eth-mainnet.g.alchemy.com/v2";

export type AssetTransfer = {
  hash: string;
  from: string;
  to: string;
  value: number | null;
  asset: string | null;
  category: string;
  blockNum: string;
};

export async function getAssetTransfersForAddress(address: string): Promise<AssetTransfer[]> {
  const apiKey = process.env.ALCHEMY_API_KEY;
  if (!apiKey) {
    throw new Error("ALCHEMY_API_KEY is not set. Add it to .env.local.");
  }

  const url = `${ALCHEMY_BASE}/${apiKey}`;

  const body = {
    jsonrpc: "2.0",
    id: 1,
    method: "alchemy_getAssetTransfers",
    params: [
      {
        fromBlock: "0x0",
        toBlock: "latest",
        toAddress: address,
        category: ["external", "erc20", "erc721", "erc1155"],
        withMetadata: false,
        excludeZeroValue: true,
        maxCount: "0x64", // 100 results
      },
    ],
  };

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    throw new Error(`Alchemy request failed: ${res.status} ${res.statusText}`);
  }

  const data = await res.json();

  if (data.error) {
    throw new Error(`Alchemy error: ${data.error.message}`);
  }

  const transfers = data.result?.transfers ?? [];

  return transfers.map((t: any) => ({
    hash: t.hash,
    from: t.from,
    to: t.to,
    value: t.value,
    asset: t.asset,
    category: t.category,
    blockNum: t.blockNum,
  }));
}
