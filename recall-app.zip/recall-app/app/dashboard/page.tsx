"use client";

import { useState } from "react";
import Navbar from "@/components/Navbar";
import ConnectWalletButton from "@/components/ConnectWalletButton";
import Timeline from "@/components/Timeline";
import WalletHealthCard from "@/components/WalletHealthCard";
import AskRecall from "@/components/AskRecall";
import AirdropRadar from "@/components/AirdropRadar";
import {
  mockTimeline,
  mockWalletHealth,
  mockAirdrops,
  mockDNA,
  mockAskRecallSamples,
} from "@/lib/mockData";

export default function Dashboard() {
  const [connectedAddress, setConnectedAddress] = useState<string | null>(null);
  const [liveTransferCount, setLiveTransferCount] = useState<number | null>(null);
  const [loadingLive, setLoadingLive] = useState(false);

  async function handleConnected(address: string) {
    setConnectedAddress(address);
    setLoadingLive(true);
    try {
      const res = await fetch(`/api/wallet/transactions?address=${address}&chain=evm`);
      const data = await res.json();
      setLiveTransferCount(data.transfers?.length ?? 0);
    } catch {
      setLiveTransferCount(null);
    } finally {
      setLoadingLive(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-6xl px-6 py-12">
        <div className="mb-10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl text-paper md:text-3xl">Your Recall</h1>
            <p className="mt-1 text-sm text-ash">
              {connectedAddress
                ? "Connected — live data below reflects your real wallet where available."
                : "Connect a wallet to pull real on-chain data. The panels below use sample data until you do."}
            </p>
          </div>
          <ConnectWalletButton onConnected={handleConnected} />
        </div>

        {connectedAddress && (
          <div className="mb-10 rounded-xl border border-teal/30 bg-teal/5 px-5 py-4 font-mono text-xs text-teal">
            {loadingLive
              ? "Fetching live transfer history from Alchemy…"
              : liveTransferCount !== null
              ? `Live: found ${liveTransferCount} on-chain transfers for this address via Alchemy.`
              : "Connected, but live transfer fetch requires ALCHEMY_API_KEY to be set in .env.local."}
          </div>
        )}

        <div className="mb-10 grid gap-6 rounded-2xl border border-white/10 bg-ink-light p-6 sm:grid-cols-3">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-ash">Risk Profile</p>
            <p className="mt-1 font-display text-xl text-signal">{mockDNA.riskProfile}</p>
          </div>
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-ash">
              Trading Personality
            </p>
            <p className="mt-1 font-display text-xl text-signal">{mockDNA.personality}</p>
          </div>
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-ash">
              Opportunity Score
            </p>
            <p className="mt-1 font-display text-xl text-signal">{mockDNA.opportunityScore}/100</p>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <div className="rounded-2xl border border-white/10 bg-ink-light p-6">
            <p className="mb-6 font-mono text-xs uppercase tracking-widest text-ash">
              Recall Timeline™
            </p>
            <Timeline entries={mockTimeline} />
          </div>

          <div className="space-y-6">
            <WalletHealthCard
              score={mockWalletHealth.score}
              breakdown={mockWalletHealth.breakdown}
            />
            <AirdropRadar airdrops={mockAirdrops} />
          </div>
        </div>

        <div className="mt-6">
          <AskRecall samples={mockAskRecallSamples} />
        </div>
      </main>
    </>
  );
}
