import Link from "next/link";
import Navbar from "@/components/Navbar";
import Timeline from "@/components/Timeline";
import { mockTimeline } from "@/lib/mockData";

const plans = [
  {
    name: "Free",
    price: "$0",
    features: ["1 wallet", "Basic dashboard", "Timeline"],
  },
  {
    name: "Pro",
    price: "$12",
    features: ["Unlimited wallets", "AI reports", "Airdrop radar", "Wallet health", "Ask Recall"],
    highlighted: true,
  },
  {
    name: "Pro+",
    price: "$29",
    features: ["Tax exports", "Smart wallet analysis", "Opportunity engine"],
  },
  {
    name: "Whale",
    price: "$99",
    features: ["Advanced analytics", "Team accounts", "API access"],
  },
];

const features = [
  { title: "Recall Timeline™", body: "Your crypto history, laid out like a film reel — every buy, miss, and loss in order." },
  { title: "Ask Recall™", body: "Ask plain-language questions about your own on-chain past and get grounded answers." },
  { title: "Airdrop Radar™", body: "Surfaces unclaimed rewards and forgotten tokens across every wallet you connect." },
  { title: "Wallet Health™", body: "A 0–100 score covering dangerous approvals, concentration, and scam exposure." },
  { title: "Money Leak Detector™", body: "Finds the repeated mistakes quietly draining your portfolio." },
  { title: "Smart Wallet Clustering™", body: "Connect one wallet, and Recall maps the related ones you forgot about." },
];

export default function Home() {
  return (
    <>
      <Navbar />

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-6 pb-20 pt-16 md:pt-24">
        <div className="grid gap-12 md:grid-cols-2 md:items-center">
          <div>
            <p className="mb-4 font-mono text-xs uppercase tracking-widest text-signal">
              The memory layer for crypto
            </p>
            <h1 className="font-display text-4xl leading-tight text-paper md:text-5xl">
              Your entire crypto history.{" "}
              <span className="italic text-signal">Finally explained.</span>
            </h1>
            <p className="mt-6 max-w-md text-ash">
              Connect your wallets. Recall discovers forgotten assets, analyzes mistakes, finds
              opportunities, and turns years of transactions into clear intelligence.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                href="/dashboard"
                className="rounded-full bg-signal px-6 py-3 text-sm font-medium text-ink hover:opacity-90"
              >
                Connect Wallet
              </Link>
              <Link
                href="/dashboard"
                className="rounded-full border border-white/15 px-6 py-3 text-sm text-paper hover:border-signal/50"
              >
                Get My Recall Report
              </Link>
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-ink-light p-8">
            <p className="mb-6 font-mono text-xs uppercase tracking-widest text-ash">
              Recall Timeline™
            </p>
            <Timeline entries={mockTimeline} />
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="border-t border-white/5 bg-ink-light/40">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <h2 className="font-display text-2xl text-paper md:text-3xl">
            Every wallet tells you what you have.
            <br />
            <span className="italic text-signal">Recall tells you what happened.</span>
          </h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {features.map((f) => (
              <div key={f.title}>
                <h3 className="font-display text-lg text-paper">{f.title}</h3>
                <p className="mt-2 text-sm text-ash">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="font-display text-2xl text-paper md:text-3xl">Pricing</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-4">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`rounded-2xl border p-6 ${
                plan.highlighted
                  ? "border-signal bg-signal/5"
                  : "border-white/10 bg-ink-light"
              }`}
            >
              <h3 className="font-display text-lg text-paper">{plan.name}</h3>
              <p className="mt-2 font-mono text-2xl text-signal">
                {plan.price}
                <span className="text-sm text-ash">/mo</span>
              </p>
              <ul className="mt-5 space-y-2 text-sm text-ash">
                {plan.features.map((f) => (
                  <li key={f}>· {f}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-white/5 px-6 py-10 text-center text-xs text-ash">
        Recall — not another wallet. A permanent AI memory for everything you've done on-chain.
      </footer>
    </>
  );
}
