import { NextRequest, NextResponse } from "next/server";
import { getAssetTransfersForAddress } from "@/lib/alchemy";

// GET /api/wallet/health?address=0x...
//
// V1 heuristic: counts inbound token diversity + transfer volume as a
// rough proxy for wallet concentration risk. Swap in a real risk model
// (e.g. approval scanning via Etherscan/Alchemy simulate, GoPlus Security
// API, or a custom scam-token denylist) as the next iteration.
export async function GET(req: NextRequest) {
  const address = req.nextUrl.searchParams.get("address");

  if (!address) {
    return NextResponse.json({ error: "Missing 'address' query param." }, { status: 400 });
  }

  try {
    const transfers = await getAssetTransfersForAddress(address);

    const uniqueAssets = new Set(transfers.map((t) => t.asset).filter(Boolean));
    const nftTransfers = transfers.filter(
      (t) => t.category === "erc721" || t.category === "erc1155"
    );

    // Placeholder scoring — replace with real approval + scam-token analysis.
    const concentrationPenalty = uniqueAssets.size <= 1 ? 20 : 0;
    const score = Math.max(0, Math.min(100, 90 - concentrationPenalty));

    return NextResponse.json({
      address,
      score,
      signals: {
        uniqueAssetsSeen: uniqueAssets.size,
        totalTransfers: transfers.length,
        nftTransfers: nftTransfers.length,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Unknown error" }, { status: 500 });
  }
}
