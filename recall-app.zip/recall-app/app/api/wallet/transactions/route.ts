import { NextRequest, NextResponse } from "next/server";
import { getAssetTransfersForAddress } from "@/lib/alchemy";
import { getSolanaTransactionsForAddress } from "@/lib/helius";

// GET /api/wallet/transactions?address=0x...&chain=evm|solana
export async function GET(req: NextRequest) {
  const address = req.nextUrl.searchParams.get("address");
  const chain = req.nextUrl.searchParams.get("chain") ?? "evm";

  if (!address) {
    return NextResponse.json({ error: "Missing 'address' query param." }, { status: 400 });
  }

  try {
    if (chain === "solana") {
      const transactions = await getSolanaTransactionsForAddress(address);
      return NextResponse.json({ chain, address, transactions });
    }

    const transfers = await getAssetTransfersForAddress(address);
    return NextResponse.json({ chain, address, transfers });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Unknown error" }, { status: 500 });
  }
}
